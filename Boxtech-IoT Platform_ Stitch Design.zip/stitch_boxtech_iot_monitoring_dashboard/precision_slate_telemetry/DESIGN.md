---
name: Precision Slate Telemetry
colors:
  surface: '#f9f9ff'
  surface-dim: '#d0daf2'
  surface-bright: '#f9f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f0f3ff'
  surface-container: '#e8eeff'
  surface-container-high: '#dfe8ff'
  surface-container-highest: '#d9e3fb'
  on-surface: '#111c2d'
  on-surface-variant: '#45464d'
  inverse-surface: '#273143'
  inverse-on-surface: '#ecf0ff'
  outline: '#76777d'
  outline-variant: '#c6c6cd'
  surface-tint: '#565e74'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#131b2e'
  on-primary-container: '#7c839b'
  inverse-primary: '#bec6e0'
  secondary: '#545f73'
  on-secondary: '#ffffff'
  secondary-container: '#d5e0f8'
  on-secondary-container: '#586377'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#0f1c2d'
  on-tertiary-container: '#778599'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dae2fd'
  primary-fixed-dim: '#bec6e0'
  on-primary-fixed: '#131b2e'
  on-primary-fixed-variant: '#3f465c'
  secondary-fixed: '#d8e3fb'
  secondary-fixed-dim: '#bcc7de'
  on-secondary-fixed: '#111c2d'
  on-secondary-fixed-variant: '#3c475a'
  tertiary-fixed: '#d6e3fb'
  tertiary-fixed-dim: '#bac7de'
  on-tertiary-fixed: '#0f1c2d'
  on-tertiary-fixed-variant: '#3b485a'
  background: '#f9f9ff'
  on-background: '#111c2d'
  surface-variant: '#d9e3fb'
typography:
  display-kpi:
    fontFamily: Space Grotesk
    fontSize: 36px
    fontWeight: '600'
    lineHeight: 44px
    letterSpacing: -0.02em
  display-kpi-mobile:
    fontFamily: Space Grotesk
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: 0em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  metric-val:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  data-mono:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-md:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.04em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-mobile: 0.75rem
  margin: 1.5rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
  space-2xl: 2rem
---

## Brand & Style

This design system establishes a high-density, analytical environment engineered for real-time industrial and enterprise hardware telemetry. The aesthetic prioritizes absolute legibility, spatial discipline, and reduced visual fatigue during extended monitoring shifts. By eliminating decorative hues and saturated non-semantic accents, the interface acts as a silent, high-fidelity substrate where only abnormal states and critical threshold shifts demand visual processing power.

The visual style is **High-Precision Technical Minimalism**:
- **Pure Functional Restraint:** Structural elements rely on hairline borders, muted neutral fills, and crisp micro-geometry rather than colorful chrome.
- **Immediate Status Comprehension:** Chromatic priority is strictly reserved for operational state indicators (nominal, degraded, critical, offline). 
- **Industrial Precision:** Balanced tabular numeric layouts, strict typographic modularity, and tight information hierarchy evoke modern control-room hardware and instrumentation panels.

## Colors

The chromatic architecture enforces a monochrome foundation where data and machine status hold the highest contrast.

### Core Canvas & Neutrals
- **App Canvas Background:** `#F8F9FA` to `#F7F8FA`
- **Surface Elevation (Cards, Panels, Modals):** `#FFFFFF`
- **Primary Text & High-Priority Readouts:** `#1A1F29`
- **Secondary Body & Metadata:** `#475467`
- **Muted Supporting Labels & Micro-copy:** `#667085`
- **Subtle Surface Dividers & Micro-Borders:** `#EAECF0` to `#E4E7EC`
- **Input Borders & Interactive Stroke Default:** `#D0D5DD`

### Primary Interactive Palette
- **Primary Interactive (Default):** `#0F172A`
- **Primary Interactive (Hover):** `#1E293B`
- **Interactive Focus Ring:** `#0F172A` with 2px offset or 15% alpha wash.

### Semantic Telemetry Status (Restricted Saturation)
- **Normal / Online:** `#12B76A` (Emerald) | Tint Background: `#ECFDF3` | Stroke: `#A6F4C5`
- **Warning / Degraded:** `#F79009` (Amber) | Tint Background: `#FEF0C7` | Stroke: `#FEDF89`
- **Critical / Alarm:** `#F04438` (Crimson) | Tint Background: `#FEF3F2` | Stroke: `#FECDCA`
- **Offline / Stale:** `#98A2B3` (Neutral Slate Gray) | Tint Background: `#F2F4F7` | Stroke: `#EAECF0`

## Typography

Typography establishes structural balance between technical geometry and tabular readability. 

- **Space Grotesk** is reserved for dashboard page titles, telemetry card titles, big numbers, gauges, counters, and high-impact hardware metrics.
- **Inter** handles high-density data tables, device configuration properties, form inputs, tooltips, and system operational messages.
- Enable `font-feature-settings: "tnum" 1` across all numerical data presentations to ensure tabular alignment in metrics, timestamps, and log streams.
- All small badge labels and table header titles must use `label-sm` with upper or title casing to cleanly demarcate boundaries between content and interface scaffolding.

## Layout & Spacing

The layout is built upon an operational fluid-grid structure optimized for high-density dashboard real estate and responsive fleet management.

- **Desktop (1200px+):** 12-column dynamic grid, 16px (`1rem`) gutters, 24px (`1.5rem`) viewport padding. Max content bounds default to edge-to-edge container logic with fixed left-rail navigation (64px collapsed, 240px expanded).
- **Tablet (768px - 1199px):** 8-column layout, 16px (`1rem`) gutters, 16px (`1rem`) edge padding. Multi-metric telemetry tiles wrap into 2x2 card clusters.
- **Mobile (< 768px):** 4-column layout, 12px (`0.75rem`) gutters, 16px (`1rem`) edge padding. Telemetry widgets drop secondary visualizations and collapse into stacked status lists.
- **Density Principle:** Component internal vertical padding is deliberately compressed (`space-xs` and `space-sm`) across table cells and list rows to allow monitoring personnel to review hundreds of sensor feeds without excessive paging.

## Elevation & Depth

This design system rejects deep drop-shadows and heavy blur effects in favor of razor-sharp separation and ambient atmospheric lift.

- **Surface Level 0 (Canvas):** Pure `#F8F9FA`. Recessed areas (such as console logs or terminal readouts) use `#F2F4F7` with an inset `1px solid #EAECF0` micro-border.
- **Surface Level 1 (Default Metric Tile & Card):** Pure `#FFFFFF` fill bounded by `1px solid #EAECF0`. Shadow is an airy, ambient diffusion: `0px 1px 2px rgba(16, 24, 40, 0.04)`.
- **Surface Level 2 (Interactive Hover / Focus State):** Retains `#FFFFFF` surface with elevated stroke `#D0D5DD` and a soft composite drop: `0px 4px 8px -2px rgba(16, 24, 40, 0.06), 0px 2px 4px -2px rgba(16, 24, 40, 0.03)`.
- **Surface Level 3 (Flyouts, Popovers, Dropdowns):** `#FFFFFF` fill with `1px solid #E4E7EC` and `0px 12px 16px -4px rgba(16, 24, 40, 0.08), 0px 4px 6px -2px rgba(16, 24, 40, 0.03)`.
- **Modal / Urgent Diagnostic Overlays:** `#FFFFFF` fill with backdrop dimming of `#0F172A` at 35% opacity.

## Shapes

The shape system employs disciplined, soft industrial rounding (`roundedness: 1`):
- **Micro-corners (4px / 0.25rem):** Form inputs, buttons, table cell selections, tooltips, and data chips.
- **Tile/Card corners (8px / 0.5rem):** Dashboard containers, monitoring tiles, modal dialogues, and chart panels.
- **Pill badge exception (Full rounded / 9999px):** Applied exclusively to compact semantic device status badges (e.g., "ONLINE", "CRITICAL") to visually isolate telemetry health from structural rectangular frames.

## Components

### Buttons
- **Primary:** Background `#0F172A`, text `#FFFFFF`, border `none`, border-radius `4px`. Hover: `#1E293B`. Active: `#020617`. Focus: 2px solid `#0F172A` with 2px white offset.
- **Secondary (Outline):** Background `#FFFFFF`, border `1px solid #D0D5DD`, text `#1A1F29`. Hover: `#F8F9FA` with border `#98A2B3`.
- **Tertiary (Ghost):** Background transparent, text `#475467`. Hover: `#F2F4F7`, text `#1A1F29`.
- **Destructive:** Background `#F04438`, text `#FFFFFF`. Hover: `#D92D20`.

### Status Badges & Chips
- **Geometry:** Height 20px–22px, border-radius `9999px`, horizontal padding `8px`, typography `label-sm`.
- **Online Badge:** Background `#ECFDF3`, border `1px solid #A6F4C5`, text `#027A48`. Optional 6px solid circular pulse dot in `#12B76A`.
- **Warning Badge:** Background `#FEF0C7`, border `1px solid #FEDF89`, text `#B54708`. Pulse dot `#F79009`.
- **Alarm Badge:** Background `#FEF3F2`, border `1px solid #FECDCA`, text `#B42318`. Pulse dot `#F04438`.
- **Offline Badge:** Background `#F2F4F7`, border `1px solid #EAECF0`, text `#344054`. Solid dot `#98A2B3`.

### Data Cards & KPI Tiles
- **Structure:** Background `#FFFFFF`, border `1px solid #EAECF0`, border-radius `8px`, padding `16px`.
- **Content Flow:** Header section with micro-label (`label-sm`, `#667085`) paired with trailing status badge. Center block features `display-kpi` or `metric-val` in `#1A1F29` with attached unit measure (`body-sm`, `#667085`). Bottom bar contains mini sparkline or delta readout.

### Input Fields & Controls
- **Text Inputs:** Height 36px, background `#FFFFFF`, border `1px solid #D0D5DD`, border-radius `4px`, padding `0 12px`, typography `body-md`. Focus: Border `#0F172A` with 1px outline.
- **Checkboxes & Radios:** 16x16px boxes, border `1px solid #D0D5DD`, checked state `#0F172A` with pure white checkmark/dot.

### Data Tables
- **Header:** Height 36px, background `#F8F9FA`, border-bottom `1px solid #EAECF0`, typography `label-sm` (`#475467`, uppercase, tracking +0.04em).
- **Row:** Height 44px, background `#FFFFFF`, border-bottom `1px solid #EAECF0`. Hover: `#F8F9FA`. Text `#1A1F29`, numerical values formatted with `data-mono`.

### Device List Items
- **Container:** Compact horizontal row, padding `10px 14px`, 1px separated, featuring a left-anchored state indicator bar or 8px radial status light, device UUID in monospaced format, firmware/hardware tag, and real-time latency readout.